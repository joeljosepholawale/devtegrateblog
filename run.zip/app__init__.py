app.config["THEME_IMG_FOLDER"] = os.path.join(app.static_folder, "Pictures_Themes")
