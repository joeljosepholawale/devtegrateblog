# Comments and replies

comment_data = [
    {
        "text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed pharetra lectus sed nulla scelerisque tempus."
    },
    {
        "text": "Ed do eiusmod tempor incididunt ut labore et dolore magna aliqua"
    },
    {
        "text": "Sed pharetra lectus sed nulla scelerisque tempus."
    },
    {
        "text": "Thank you for such a great post.",
    },
    {
        "text": "I have a question about this.",
    },
    {
        "text": "Let me know, happy to answer.",
    },
    {
        "text": "This sounds like an awesome trip.",
    },
    {
        "text": "Yes, I like it too.",
    }
]
