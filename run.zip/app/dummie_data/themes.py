# Themes

themes_data = [
    {
        "theme": "Beach",
        "picture": "Picture_theme_1.jpg",
        "picture_source": "https://pixabay.com/photos/beach-san-blas-islands-panama-4388225/"
    },
    {
        "theme": "City",
        "picture": "Picture_theme_2.jpg",
        "picture_source": "https://pixabay.com/photos/chain-bridge-budapest-travel-bridge-2733049/"
    },
    {
        "theme": "Nature",
        "picture": "Picture_theme_3.jpg",
        "picture_source": "https://pixabay.com/photos/mckenzie-river-central-oregon-forest-5129717//"
    },
    {
        "theme": "Culture",
        "picture": "Picture_theme_4.jpg",
        "picture_source": "https://pixabay.com/photos/hiroshima-japan-japanese-landmark-725801/"
    }
]
