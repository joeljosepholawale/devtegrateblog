# Author information

authors_data = [
    {
        "name": "Elisa S.",
        "picture": "Picture_author_1.jpg",
        "picture_source": "https://pixabay.com/photos/woman-camera-photographer-tool-5584377/"
    },
    {
        "name": "Ricardo J. F.",
        "picture": "Picture_author_2.jpg",
        "picture_source": "https://pixabay.com/photos/man-coffee-outdoors-lake-lakeside-3803551/"
    },
    {
        "name": "Martha P.",
        "picture": "Picture_author_3.jpg",
        "picture_source": "https://pixabay.com/photos/attractive-beautiful-girl-model-1869761/"
    }
]
authors_about = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu massa eget massa maximus ultricies condimentum ut urna. Aenean imperdiet felis laoreet sem tristique, a tincidunt ligula egestas. Donec facilisis sodales mi. Morbi id feugiat lorem. Donec finibus luctus libero congue bibendum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Sed aliquam urna id congue. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Sed aliquam urna id congue."
